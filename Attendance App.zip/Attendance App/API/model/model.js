const connection = require("./dbSetup");
const formatDate = require('date-and-time');
let model = {};

model.getAttendance = async (date) => {
  const [result] = await connection.query("select * from users u join dailyAttendance a on u.id = a.id where day = '" + date + "';");
  let returnData = {};
  if (result.length) {
    result.forEach(user => {
      user.present = user.present === 1 ? true : false;
      user.day = formatDate.format(new Date(user.day),'YYYY-MM-DD'); 
    });
    returnData = {
      attendanceEntered: true,
      users: result
    };
  } else {
    const [users] = await connection.query("select * from users;");
    returnData = {
      attendanceEntered: false,
      users
    };
  }
  return returnData;
};

model.getAttendanceReport = async () => {
 const queryTotalRecords = "select count(day) as noOfDays, u.id, u.name from dailyAttendance a JOIN users u on u.id = a.id group by u.id order by u.id;";
 const queryPresentRecords = "select count(day) as attendance, u.id, u.name from dailyAttendance a JOIN users u on u.id = a.id where present = 1 group by u.id order by u.id;";
 const [totalRecord] = await connection.query(queryTotalRecords);
 const [presentRecord] = await connection.query(queryPresentRecords);
 const returnData = [];
 for(let i = 0; i < totalRecord.length; i++){
  const totalData = totalRecord[i];
  const presentData = presentRecord[i];
  const data = {
    id:totalData.id, 
    name: totalData.name, 
    attendance:`${presentData.attendance} / ${totalData.noOfDays}`,
    percentage: `${parseFloat((presentData.attendance / totalData.noOfDays * 100)).toFixed(2)} %`
  };
  returnData.push(data);
 }
 return returnData;
};

model.submitAttendance = async (obj) => {
  let query = "insert into dailyAttendance(day, id, present) values";
  const date = obj.date;
  obj.users.forEach((element, index) => {
    query = query + `('${date}', ${element.id}, ${element.present})${(index !== obj.users.length - 1) ? ',' : ';'}`;
  });
  await connection.query(query);
  const returnData = await model.getAttendance(date);
  return returnData;
};

model.setup = async () => {
  await connection.query("DROP TABLE IF EXISTS dailyAttendance;");
  await connection.query("DROP TABLE IF EXISTS users;");
  await connection.query("create table users (id int NOT NULL, name varchar(255) NOT NULL, PRIMARY KEY(id));");
  await connection.query("create table dailyAttendance (day DATE, id int, present BOOLEAN, FOREIGN KEY (id) REFERENCES users(id));");
  await connection.query("insert into users(id, name) values (1,'Abhishek'), (2,'Adarsh'), (3, 'Jhanvi'), (4, 'Mohan'), (5, 'Meenakshi');");
  const [result] = await connection.query("select * from users");
  return result;
};

module.exports = model;