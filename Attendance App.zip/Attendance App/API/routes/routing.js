const express = require('express');
const routing = express.Router();
const service = require("../services/service.js");

routing.post("/submitAttendance", (req, res, next) => {
  let obj = req.body;
  return service.submitAttendance(obj).then(data => {
    res.json({ data: data });
  }).catch(err => {
    next(err);
  })
});

routing.get("/getAttendance", (req, res, next) => {
  return service.getAttendance(req.query.date).then(data => {
    res.json({ data });
  }).catch(err => {
    next(err);
  })
});

routing.get("/getAttendanceReport", (req, res, next) => {
  return service.getAttendanceReport().then(data => {
    res.json({ data });
  }).catch(err => {
    next(err);
  })
});

routing.get("/setup", (req, res, next) => {
  return service.setup().then(result => {
    res.json({ data: result });
  }).catch(err => {
    next(err);
  })
});

module.exports = routing;