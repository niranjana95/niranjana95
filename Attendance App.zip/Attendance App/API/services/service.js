const model = require("../model/model.js");
let service = {};

service.submitAttendance = (obj) => {
  return model.submitAttendance(obj).then(data => {
    if (data) {
      return data;
    } else {
      let error = new Error("Updation Failed");
      error.status = 500;
      throw error;
    }
  });
}

service.getAttendance = (date) => {
  return model.getAttendance(date).then(data => {
    if (data) {
      return data;
    } else {
      let error = new Error("Initialization Failed");
      error.status = 500;
      throw error;
    }
  });
}

service.getAttendanceReport = () => {
  return model.getAttendanceReport().then(data =>{
    if(data){
      return data;
    }else {
      let error = new Error("Repport generation failed");
      error.status = 500;
      throw error;
    }
  });
}

service.setup = () => {
  return model.setup().then(data => {
    if (data.length > 0) {
      return data;
    } else {
      let error = new Error("Failed Updating Dashboard");
      error.status = 500;
      throw error;
    }
  });
};

module.exports = service;