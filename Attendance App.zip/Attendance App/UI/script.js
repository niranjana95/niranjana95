const tableContent = document.getElementById('attendance-table-content');
const reportTableContent = document.getElementById('report-table-content');
const submitBtn = document.getElementById('submit-btn');
const tableBody = document.getElementById('attendance-table-body');
const reportTableBody = document.getElementById('report-table-body');
tableContent.style.display = "none";
submitBtn.style.display = "none";
reportTableContent.style.display = "none";
let parentUsers = [];
document.getElementById('search-btn').addEventListener('click', () => {
  const value = document.getElementById('date-value').value;
  if (value) {
    const url = `http://localhost:3000/getAttendance?date=${value}`;
    fetch(url).then(response => {
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('Data not found');
        } else if (response.status === 500) {
          throw new Error('Server error');
        } else {
          throw new Error('Network response was not ok');
        }
      }
      return response.json();
    })
      .then(data => {
        const responseData = data.data;
        addTableData(responseData);
      })
      .catch(error => {
        console.error('Error:', error);
      });
  }
});

document.getElementById('submit-btn').addEventListener('click', () => {
  const value = document.getElementById('date-value').value;
  if (value) {
    const submitData = { date: value };
    parentUsers.forEach(user => {
      radioVal = document.querySelector(`input[name="radio-${user.id}"]:checked`).value;
      user.present = radioVal === 'true' ? true : false;
    });
    submitData.users = parentUsers;
    const requestOptions = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(submitData),
    };
    const url = `http://localhost:3000/submitAttendance`;
    fetch(url, requestOptions).then(response => {
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('Data not found');
        } else if (response.status === 500) {
          throw new Error('Server error');
        } else {
          throw new Error('Network response was not ok');
        }
      }
      return response.json();
    })
      .then(data => {
        const responseData = data.data;
        addTableData(responseData);
      })
      .catch(error => {
        console.error('Error:', error);
      });
  }
});

document.getElementById('fetch-summary-btn').addEventListener('click', () => {
  const url = "http://localhost:3000/getAttendanceReport";
  fetch(url).then(response => {
    if (!response.ok) {
      if (response.status === 404) {
        throw new Error('Data not found');
      } else if (response.status === 500) {
        throw new Error('Server error');
      } else {
        throw new Error('Network response was not ok');
      }
    }
    return response.json();
  })
    .then(data => {
      const responseData = data.data;
      reportTableBody.innerHTML = "";
      if (responseData.length) {
        tableContent.style.display = "none";
        reportTableContent.style.display = "block";
        submitBtn.style.display = "none";
        responseData.forEach(user => {
          const tr = document.createElement('tr');
          const td1 = document.createElement('th');
          td1.appendChild(document.createTextNode(user.id))
          td1.setAttribute("scope", "row");
          const td2 = document.createElement('td');
          td2.appendChild(document.createTextNode(user.name));
          td2.setAttribute("scope", "row");
          const td3 = document.createElement('td');
          td3.appendChild(document.createTextNode(user.attendance));
          td3.setAttribute("scope", "row");
          const td4 = document.createElement('td');
          td4.appendChild(document.createTextNode(user.percentage));
          td4.setAttribute("scope", "row");
          tr.appendChild(td1);
          tr.appendChild(td2);
          tr.appendChild(td3);
          tr.appendChild(td4);
          reportTableBody.appendChild(tr);
        });
      }
    })
    .catch(error => {
      console.error('Error:', error);
    });
});

const addTableData = (responseData) => {
  reportTableContent.style.display = "none";
  const users = responseData.users;
  parentUsers = users;
  tableBody.innerHTML = "";
  if (users.length) {
    tableContent.style.display = "block";
    users.forEach(user => {
      const tr = document.createElement('tr');
      const td1 = document.createElement('th');
      td1.appendChild(document.createTextNode(user.id))
      td1.setAttribute("scope", "row");
      const td2 = document.createElement('td');
      td2.appendChild(document.createTextNode(user.name));
      td2.setAttribute("scope", "row");
      const td3 = document.createElement('td');
      td3.setAttribute("scope", "row");
      if (responseData.attendanceEntered) {
        submitBtn.style.display = "none";
        const icon = document.createElement("i");
        icon.className = user.present ? "bi bi-check-circle-fill text-success" : "bi bi-x-circle text-danger";
        td3.appendChild(icon);
      } else {
        submitBtn.style.display = "block";
        const parentDiv = document.createElement('div');
        const presentDiv = document.createElement('div');
        presentDiv.className = "form-check form-check-inline";
        const radio1 = document.createElement("input");
        radio1.value = true;
        radio1.type = "radio";
        radio1.name = `radio-${user.id}`;
        radio1.className = "form-check-input";
        radio1.id = `${user.id}-1`;
        const label1 = document.createElement("label");
        label1.appendChild(document.createTextNode("Present"));
        label1.className = "form-check-label";
        label1.setAttribute("for", `${user.id}-1`);
        presentDiv.appendChild(radio1);
        presentDiv.appendChild(label1);
        const absentDiv = document.createElement('div');
        absentDiv.className = "form-check form-check-inline";
        const radio2 = document.createElement("input");
        radio2.value = false;
        radio2.type = "radio";
        radio2.name = `radio-${user.id}`;
        radio2.className = "form-check-input";
        radio2.id = `${user.id}-2`;
        const label2 = document.createElement("label");
        label2.appendChild(document.createTextNode("Absent"));
        label1.className = "form-check-label";
        label1.setAttribute("for", `${user.id}-2`);
        absentDiv.appendChild(radio2);
        absentDiv.appendChild(label2);
        parentDiv.appendChild(presentDiv);
        parentDiv.appendChild(absentDiv);
        td3.appendChild(parentDiv);
      }
      tr.appendChild(td1);
      tr.appendChild(td2);
      tr.appendChild(td3);
      tableBody.appendChild(tr);
    });
  } else {
    tableContent.style.display = "none";
  }
};